package edu.cs.uga.trophyteam;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //Retrieve Primary Toolbar
        Toolbar myToolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);

        //Display existing, non completed exercises
        //TODO: Make a way to know if an exercise has been completed or not



        //Start Tester for Exercise Classes
        Tester.StartTestExerciseCardio();
    }

    /***
     * Method that inflates the Primary Menu to the Toolbar
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.actionbar_primary, menu);
        return true;
    }

    /***
     * Method that allows the user to navigate between pages via the Toolbar
     *
     * @param item The MenuItem selected by the user
     * @return true If a valid options was selected
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.action_add_exercise:
                startActivity(new Intent(HomeActivity.this, AddCardioExerciseActivity.class));
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return super.onOptionsItemSelected(item);
    }
}
